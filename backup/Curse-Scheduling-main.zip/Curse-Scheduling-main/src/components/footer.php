<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Footer -->
<!-- <footer class="bg-black mt-16 shadow-inner">
  <div class="max-w-7xl mx-auto px-4 py-6 text-center text-yellow-500 text-sm">
    © 2025 CSS. All rights reserved.
  </div>
</footer> -->

</body>
</html>